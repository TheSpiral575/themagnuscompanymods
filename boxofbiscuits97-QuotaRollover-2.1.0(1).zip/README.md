# Quota Rollover
### Anti-hoarding technology that only removes required credits for the quota instead of setting progress to 0

## Changelog
- v2.1.0
	- Finally Fixed an issue where quotas would be redeemed early

- v2.0.0
	- Support for clients to see things properly! (Instead of just the host)

- v1.1.0
	- Actually uploaded the mod file instead of my suits mod (I'm an idiot)
	
- v1.0.0
	- Initial Release 
	- Only host is required for working mod
		- Clients are desynced visually