# Install: 
Extract and Drop the BepInEx folder into the LethalCompany game folder

# Description:
Adds employee assignments, each time you land on a moon players will randomly be selected for assignment. When a player is selected they will be given a random assignment to complete before leaving the moon, The company will reward employees who complete assignments. Hosts can adjust values and whitelists in the new config file, the settings marked HostOnly will not be used if not the game host.

Current Assignment Types:
+ Scrap Retrieval (Collect specific scrap item, it will have the name "ASSIGNMENT TARGET")
+ Hunt & Kill Monster
+ Repair Broken Valve

Planned Assignment Types:
+ Employee Termination
+ And more

# Scrap Retrieval
You will be notified of the item type at the start of the round, you must find the exact item named "ASSIGNMENT TARGET" and return it to the ship.
Once returned the value of the item will be adjuted to show the correct value of this sepcial item. If collected by another employee the company will only pay the normal item value.

# Hunt & Kill Monster
You will be tasked with hunting down an enemy, you will be told the enemy type you must track down at the start of the round, If you kill the assigned enemy it will drop a reward regardless of the player who killed it.

# Repair Broken Valve
The company sensors have detected a valve leak, its location has been sent to your new Assignment Tracker Interface. Locate the valve and repair it. Once repaired a reward will drop.

# Feedback and Bug Reporting
If you have any suggestions, feedback or bugs to report please head over to the discord post thread here
https://discord.com/channels/1168655651455639582/1181269110684909598

Thanks to the testers helping out from discord

Darkmega
Portokalis
Moroxide
atony
grey
HipposaauR