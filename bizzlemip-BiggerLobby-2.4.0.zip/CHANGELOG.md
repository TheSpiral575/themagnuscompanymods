# 2.4.0
+ Hopefully fixed object sync bug when players not set to 16
+ Updated thunderstore link to include source
+ Added explicit non-compatibilty with some earlier versions - make sure everybody updates their mod if you want to play together!
# 2.3.1
+ Updated thunderstore README
+ Added CHANGELOG.md
+ Use Release Mode for .dll
# 2.3.0
+ Fixed sync bug caused by logging
# 2.2.71
+ Fixed major bug lol
# 2.2.70
+ Voice chat is now louder, mod optimized a ton!
+ New config for changing player volume.
# 2.2.60
+ BiggerLobby servers are now more distinguished in the serverlist. This version is cross compatible with all 2.2.5 versions, so there is no immediate need to upgrade.
# 2.2.53
+ markdown updates
# 2.2.5
+ More issues fixed regarding stability as a whole, dynamic player patching was removed in favor of stability, as it seemed the patching was inconsistent.
# 2.2.4
+ Issue fixed with ending a match! Really sorry about that guys, somehow the issue never showed up at all during testing, and only appeared after I released the update. Such is the way of the modder XD
# 2.2.3
+ 50 max players!
+ SO many bugfixes relating to stability!
+ Internal networking reworked!
+ Issues with time not changing / enemies not spawning fixed!
+ Playerlist can now display up to 50 players!
