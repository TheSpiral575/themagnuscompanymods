
# BiggerLobby V2.4.0

Thank you guys for six hundred downloads! It really means a lot! I'm really glad I could make something so many people enjoyed.

## Roadmap

Optimization

Dynamic voice chat culling

Dynamic VOIP sample rate.

##

[Discord Server](https://discord.gg/lcmods)